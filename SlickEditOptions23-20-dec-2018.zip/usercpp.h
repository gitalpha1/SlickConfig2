#undef _NTDDK_ 

#undef UBUS_PORT_IS_DEBUG 

